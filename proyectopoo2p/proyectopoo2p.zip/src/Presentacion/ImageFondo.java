/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentacion;

import javafx.geometry.Point2D;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.*;
import javafx.event.EventType;



/**
 *
 * @author jonax
 */

public class ImageFondo extends Rectangle{
    private static final String image_path = "image/alien.png";
    
    
    
    public ImageFondo (Pane root,double alto, double ancho){
        super(400,400);
        //aqui da el error
        Image img = new Image(image_path);
        ImagePattern imagePattern = new ImagePattern(img);
        this.setFill(imagePattern);
        root.getChildren().add(this);
        setPosition();

    }
    
    public void setPosition(){
        this.setTranslateX(0);
        this.setTranslateY(0);
    }
  
}

