/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentación;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Julio Alvia
 */
public class Marcador {
    private GridPane root;
    Label nombre,categoria,descripcion,imagenes;
    Button aceptar,cancelar,ima;
    TextField nombre1,categoria1,descripcion1;
    
    public Marcador(){
    root=new GridPane();
    Organizador();
    }
    public Pane getRoot() {
        return root;
    } 
    public void Organizador(){
        nombre=new Label("Nombre");
        categoria=new Label("Categoria");
        descripcion=new Label("Descripcion");
        imagenes=new Label("Imagenes");
        nombre1=new TextField();
        categoria1=new TextField();
        descripcion1=new TextField();
        aceptar=new Button("Aceptar");
        cancelar=new Button("Cancelar");
        ima=new Button("Insertar");
        root.add(nombre,2,2);
        root.add(categoria,2,3);
        root.add(descripcion,2,4);
        root.add(imagenes,2,5);
        root.add(aceptar,2,6);
        root.add(nombre1,3,2);
        root.add(categoria1,3,3);
        root.add(descripcion1,3,4);
        root.add(ima,3,5);
        root.add(cancelar,3,6);
        root.setAlignment(Pos.CENTER);
    }
    /*para probar nada mas
    @Override
    public void start(Stage stage) {
        root=new GridPane();
        Scene scene = new Scene(root,450,450);
        
        nombre=new Label("Nombre");
        categoria=new Label("Categoria");
        descripcion=new Label("Descripcion");
        imagenes=new Label("Imagenes");
        nombre1=new TextField();
        categoria1=new TextField();
        descripcion1=new TextField();
        aceptar=new Button("Aceptar");
        cancelar=new Button("Cancelar");
        ima=new Button("Insertar");
        root.add(nombre,2,2);
        root.add(categoria,2,3);
        root.add(descripcion,2,4);
        root.add(imagenes,2,5);
        root.add(aceptar,2,6);
        root.add(nombre1,3,2);
        root.add(categoria1,3,3);
        root.add(descripcion1,3,4);
        root.add(ima,3,5);
        root.add(cancelar,3,6);
        root.setAlignment(Pos.CENTER);
        
        stage.setScene(scene);
        stage.setTitle("Crear Marcador");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }*/
}
