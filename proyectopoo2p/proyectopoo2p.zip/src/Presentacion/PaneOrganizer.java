/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentacion;

/**
 *
 * @author jonax
 */

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

public class PaneOrganizer {
    
    private BorderPane _root;
    private Pane alienPane;
    
    public PaneOrganizer(){
        _root = new BorderPane();
        alienPane = new Pane();
        
        ImageFondo img = new ImageFondo(alienPane, 400, 400);
        
        _root.setCenter(alienPane);
        
    }

    public Pane getAlienPane() {
        return alienPane;
    }
    
}
